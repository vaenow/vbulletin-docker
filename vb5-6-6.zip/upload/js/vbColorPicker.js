/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.6.6
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2022 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
var vBulletin_ColorPicker=function(g,a){$("<link>").appendTo("head").attr({rel:"stylesheet",type:"text/css",href:pageData.baseurl+"/js/colorpicker/css/colorpicker.css"});(function(){$(g).each(function(){var c=$(this),d=$('<span class="'+(a.triggerClass?a.triggerClass:"colorPickerTrigger")+'"></span>').insertBefore(c);d.css("backgroundColor",c.val());var b=d.css("backgroundColor");c.off("keyup").on("keyup",function(){/^[0-9a-f]{3}(?:[0-9a-f]{3})?$/i.test(c.val())&&c.val("#"+c.val());d.css("backgroundColor",
c.val());d.ColorPickerSetColor(d.css("backgroundColor"));if(a.onChange){var e=d.ColorPickerGetColor();a.onChange.call(c,"#"+e.hex)}});b={color:a.color?a.color:b,onChange:function(e,f,b){c.val("#"+f);d.css("backgroundColor","#"+f);a.onChange&&a.onChange.call(c,"#"+f)},onSubmit:function(e,b,g,h){$(h).val(b);c.val("#"+b);d.css("backgroundColor","#"+b);a.onSubmit&&"function"==typeof a.onSubmit&&a.onSubmit.call(c,"#"+b)}};a.fadeIn&&(b.onShow=function(b){$(b).fadeIn(a.fadeSpeed?a.fadeSpeed:500);a.onShow&&
a.onShow.call(b);return!1});a.fadeOut&&(b.onHide=function(b){$(b).fadeIn(a.fadeSpeed?a.fadeSpeed:500);a.onHide&&a.onHide.call(b);return!1});!a.fadeIn&&a.onShow&&(b.onShow=a.onShow);!a.fadeOut&&a.onHide&&(b.onHide=a.onHide);d.ColorPicker(b)})})()};
