/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.6.6
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2022 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
(function(){function b(a,b){var d=e;a=a.split(".");for(var c=0;c<a.length-1;c++)d=d[a[c]]=d[a[c]]||{};return d[a[c]]=d[a[c]]||b||{}}var e=vBulletin={};e.ensureObj=b;e.ensureFun=function(a){return"function"==typeof a?a:function(){}};b("Responsive.Debounce").checkBrowserSize=function(){if(Modernizr){var a=document.body;a.classList.toggle("l-xsmall",Modernizr.mq("(max-width: 479px)"));a.classList.toggle("l-small",Modernizr.mq("(max-width: 767px)"));a.classList.toggle("l-desktop",Modernizr.mq("(min-width: 768px)"))}};
var f=b("phrase.precache",[]),g=b("options.precache",[]);e.precache=function(a,b){f.push(...a);g.push(...b)}})();
