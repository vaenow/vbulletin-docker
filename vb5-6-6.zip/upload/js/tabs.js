/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.6.6
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2022 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================/

/*
 This is intended to be self contained and should not refer to the
 vBulletin object, pageData or other framework.

 The filters for the toolbars are intimately connected to the tabs and are so included here.
 Not calling it tabfiltertools for brevity.

 This depends on the jquery ui tabs widget
*/
vBulletin.tabtools=function(n,p,w,x,y){function q(a){var b=$(".conversation-toolbar-wrapper",a);return"1"==(b.length?b:a).data("allow-history")}function r(a,b,f,h,l){var c=location.pathname.replace(/\/$/,"").replace(/\/page[0-9]+/,""),d=$(".toolbar-filter-overlay",a),g=z(d,!0);d=$(".pagenav-form .js-pagenum",a).val()||1;var m=$(".toolbar-search-form .js-filter-search",a).val()||"",k=$(a).closest(".canvas-widget"),e=q(a);e=new p.instance(e);k=k.data("widget-default-tab")||k.find(".ui-tabs-nav > li:first-child a").attr("href");
$.isEmptyObject(g)&&$(".conversation-toolbar .js-button-filters",a).each(function(){var a=$(".js-button-filter.js-checked:not(.js-default-checked)",this);a.length&&(g[a.data("filter-name")]=a.data("filter-name"))});f||(a=new RegExp("\\/("+h.join("|")+")/?$"),c=(a=c.match(a))?c.replace(new RegExp(a[0]),"/"+b):c+("/"+b));1<d&&e.isEnabled()&&(c+="/page"+d);f&&b&&k!="#"+b&&(g.tab=b,e.isEnabled()||(c+="?tab="+b));if(!e.isEnabled())return c+(l?"#"+l:"");m&&(g.q=m);b=$.param(g);return c+(b?"?"+b:"")+(l?
"#"+l:"")}function A(a,b,f,h,l,c){var d=$(this);if(d.length){var g=a instanceof p.instance;if(g&&a.isEnabled()){var m=c.create;c.create=function(b,c){var k=t(location.search,["_"]),e=Object.keys(k).length,g=B(d,h),l=a.getState();!(h&&1<e&&"undefined"!=typeof k.tab||!h&&0<e)||l&&!$.isEmptyObject(l.data)||a.setDefaultState({from:"tabs",tab:g},document.title,location.href);a.setStateChange(function(b){b=a.getState();if("tabs"==b.data.from){a.log(b.data,b.title,b.url);var k=f(b.data.tab),c=t(b.url,["tab",
"_"]);if(d.tabs("option","selected")!=k)C.call(d,k),$.isEmptyObject(c)||$(window).trigger("statechange.filter",["tabs",c]);else if($.isEmptyObject(c)){var e;b.data.tab&&(e=h?$(b.data.tab):$('.ui-tabs .ui-tabs-panel[data-url-path="'+b.data.tab+'"]'));e=e&&e.length&&e||$(d.closest(".canvas-widget").data("widget-default-tab"));b=$(".toolbar-filter-overlay .filter-options .js-default-checked",e);b.length?(b.prop("checked",!0).first().data("bypass-filter-display",!0).trigger("change",[!0]).data("bypass-filter-display",
null),$(".filtered-by",e).addClass("h-hide").find(".filter-text-wrapper").empty()):$(".conversation-toolbar .js-default-checked",e).first().trigger("click",[!0])}else $(window).trigger("statechange.filter",["tabs",c])}},"tabs");m.call(d[0],b,c)}}if(b&&g){var k=c.beforeActivate;c.beforeActivate=function(b,c){var e=c.newPanel,g=c.newTab;if(!1===k.call(this,b,c))return!1;c=h?e.attr("id"):g.find(".ui-tabs-anchor").data("url-path");var f=void 0;h||(f=[],d.find(".ui-tabs-nav > li > a, .widget-tabs-panel").each(function(a,
b){a=$(this).data("url-path");-1==$.inArray(a,f)&&f.push(a)}));if(!a.isEnabled())return e=r(e,c,h,f,l),location.href=e,!1;d.data("noPushState")?d.data("noPushState",null):(b={from:"tabs",tab:"#"+c},e=r(e,c,h,f),a.pushState(b,document.title,e))}}d.tabs(c)}return d}function u(a,b){return a.offset().top+(a.outerHeight()-parseFloat(a.css("border-bottom-width")))-b.height()}function D(a,b,f,h,l,c){h=$(".conversation-toolbar-wrapper.scrolltofixed-floating",a);var d=null,g=null,m=null;b&&0<h.length&&(d=
new y({element:h,limit:u(b,h)}));f&&(m=new x({context:a,allowHistory:l,onPageChanged:function(a,b){g.updatePageNumber(a);b||g.applyFilters(!1,!0,!1,!0)}}));g=new w({context:a,autoCheck:!1,scrollToTop:b,pagination:m,allowHistory:l,onContentLoad:c});return{$bar:h,$floating:d,pagination:m,filter:g}}function E(a){a.css("border-bottom","").filter(".stream-view.activity-view").find(".list-item-poll form.poll").each(function(a,f){$(this).is(":visible")&&$(".view-less-ctrl",this).hasClass("h-hide")&&F(this,
3)})}function v(a){a&&(G(a),E(a))}var t=n.parseQueryString,G=n.truncatePostContent,F=n.conversation.limitVisiblePollOptionsInAPost,B=n.getSelectedTabHashOrPath,z=n.getSelectedFilters,C=n.selectTabByIndex;ensureFun=n.ensureFun;return{initTabs:function(a,b,f,h,l,c,d,g,m){f.removeClass("ui-state-disabled");A.call(a,b,h,function(a){a=a||c;return f.filter('li:has(a[href*="'+a+'"])').first().index()},g,a.find(".js-module-top-anchor").prop("id"),{active:l,beforeActivate:function(a,b){for(var c;c<d.length;c++)d[c]&&
d[c].hideFilterOverlay()},create:function(a,b){m($(this),b.tab,b.panel)},activate:function(a,b){m($(this),b.newTab,b.newPanel)}})},newTab:function(a,b,f,h,l,c,d,g,m){var k=D(a,b,f,h,m,function(){k.$floating&&k.$floating.updateLimit(u(b,k.$bar));v(c);ensureFun(d)()});l&&(f=k.filter,v(c),ensureFun(g)(),f.lastFilters={filters:f.getSelectedFilters($(".toolbar-filter-overlay",a))});return k},tabAllowHistory:q}}(vBulletin,vBulletin.history,vBulletin.conversation.filter,vBulletin.pagination,vBulletin.scrollToFixed);
