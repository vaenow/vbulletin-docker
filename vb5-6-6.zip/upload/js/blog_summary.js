/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.6.6
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2022 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
vBulletin.precache(["blog_subscribers_list","blog_subscribers","unable_to_contact_server_please_try_again"],[]);
(function(b){if(!vBulletin.pageHasSelectors([".summary-widget",".blogadmin-widget"]))return!1;var h=function(){b("#blogSubscribersSeeAll").off("click").on("click",function(a){g(b(this).attr("data-node-id"));a.stopPropagation();return!1})},a,g=function(f,c,d){a=b("#blogSubscribersAll").dialog({title:vBulletin.phrase.get("blog_subscribers_list"),autoOpen:!1,modal:!0,resizable:!1,closeOnEscape:!1,showCloseButton:!1,width:450,dialogClass:"dialog-container dialog-box blog-subscribers-dialog"});vBulletin.pagination({context:a,
onPageChanged:function(a,b){g(f,a)}});a.off("click",".blog-subscribers-close").on("click",".blog-subscribers-close",function(){a.dialog("close")});a.off("click",".action_button").on("click",".action_button",function(){if(!b(this).hasClass("subscribepending_button")){var a=b(this),c=parseInt(a.attr("data-userid"),10),e="";a.hasClass("subscribe_button")?e="add":a.hasClass("unsubscribe_button")&&(e="delete");"number"==typeof c&&e&&vBulletin.AJAX({call:"/profile/follow-button",data:{"do":e,follower:c,
type:"follow_members"},success:function(b){if(1==b||2==b){if("add"==e){var c="subscribe_button b-button b-button--special";var d=(1==b?"subscribed":"subscribepending")+"_button b-button b-button--secondary";var f=1==b?"following":"following_pending";a.attr("disabled","disabled")}else"delete"==e&&(c="subscribed_button unsubscribe_button b-button b-button--special",d="subscribe_button b-button b-button--secondary",f="follow");a.removeClass(c).addClass(d).text(vBulletin.phrase.get(f))}},title_phrase:"profile_guser",
error_phrase:"unable_to_contact_server_please_try_again"})}});c||(c=1);d||(d=10);vBulletin.AJAX({call:"/ajax/render/subscribers_list",data:{nodeid:f,page:c,perpage:d},success:function(c){a.dialog("close");b(".blog-subscribers-content",a).html(c);a.dialog("open")},title_phrase:"blog_subscribers",error_phrase:"unable_to_contact_server_please_try_again"})};b(document).ready(function(){h()})})(jQuery);
