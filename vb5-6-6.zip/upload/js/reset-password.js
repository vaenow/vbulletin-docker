/*
 =======================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.6.6
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2022 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/
(function(a){a(function(){var b=a("#reset-password-form");b.submit(function(a){a=b.find(':input[name="new-password"]');var c=b.find(':input[name="new-password-confirm"]');return vBulletin.checkPassword(a,c)?!0:!1})})})(jQuery);
