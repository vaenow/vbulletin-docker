<?php if (!defined('VB_ENTRY')) die('Access denied.');
/*========================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.6.6 - Licence Number LL5312FB5F
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2022 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/

class localapi_Api_Main extends vB_Api
{
	public function customWidgetHtml()
	{
		//insert your custom PHP code here.
		$myhtml = '<p>Hello world</p><p><b>Hello world in bold</b></p>';
		//insert your custom PHP code here.

		return ['html' => $myhtml];
	}

	public function dataOnly()
	{
		$mydata = [
			'hello' => 'Hello world',
			'hellobold' => 'Hello world in bold',
		];

		return $mydata;
	}
}

/*=========================================================================*\
|| #######################################################################
|| # Downloaded: 22:17, Wed Feb 16th 2022
|| # CVS: $RCSfile$ - $Revision: 101016 $
|| #######################################################################
\*=========================================================================*/
