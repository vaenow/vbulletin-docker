# Including Custom PHP in Modules

We've created a new package that is intended to facilitate the replacement of custom PHP modules with custom Template Display modules.  It also demonstrates how to create custom API functions in general.

## Steps to replace a PHP module Module

### Edit the api/main.php file

1. Find the custommoduleHtml function
2. Copy your php code from the module into the function.
3. Change the code to generate a string value instead of echoing content and set that to the `$myhtml` parameter.

If you have more than one PHP module you can copy the function, give it a new name, and copy/edit the code above for each module.

4. Upload this package directory into core/packages

### Create a custom template

1. Go to the style editor in the admincp and select add a new template for the site style you are using.

2. Give it a name like 'customtemplatemodule'
3. copy the following into the template changing the name to match the function name(s) in the api/main.php:

~~~html
{vb:data result, localapi:main, customWidgetHtml}
{vb:raw result.html}
~~~

4. Do this for each PHP module you are replacing.

### Adding Your Code to a Page

1. Go to sitebuilder.  
2. Edit the page that you want to display the module on.
3. Add a "Display Template" Module to replace the PHP Module
4. Set the template name to 'customtemplatemodule' or whatever you named your new template.
5. Remove the old PHP module template
6. Save the Page.

> Note you can return html and display it from the API in this way.  It's the quickest and easiest way of porting from an existing PHP module to a Template module.  But it isn't necesarily the best way. The API functions are intended to return data that can be inserted into the markup in the templates.  And alternative example is provided in the sample class. You can uncomment the function if you want to try it out.  The template to use this to provide the same result as the sample html return is:

~~~html
{vb:data result, localapi:main, dataOnly}
<p>{vb:var result.hello}</p><p><b>{vb:var result.hellobold}</b></p>
~~~

As above save that as a custom template and create a Display Template Module that uses it.
