<?php if (!defined('VB_ENTRY')) die('Access denied.');
/*========================================================================*\
|| ###################################################################### ||
|| # vBulletin 5.6.6 - Licence Number LL5312FB5F
|| # ------------------------------------------------------------------ # ||
|| # Copyright 2000-2022 MH Sub I, LLC dba vBulletin. All Rights Reserved.  # ||
|| # This file may not be redistributed in whole or significant part.   # ||
|| # ----------------- VBULLETIN IS NOT FREE SOFTWARE ----------------- # ||
|| # http://www.vbulletin.com | http://www.vbulletin.com/license.html   # ||
|| ###################################################################### ||
\*========================================================================*/

class examplefilescan_Utility_Filescanner_Blockall extends vB_Utility_Filescanner
{
	protected function checkDependencies($vboptions)
	{
		return true;
	}

	public function scanFile($filename)
	{
		// This implementation will flag every file.

		return false;
	}
}

/*=========================================================================*\
|| #######################################################################
|| # Downloaded: 22:17, Wed Feb 16th 2022
|| # CVS: $RCSfile$ - $Revision: 102615 $
|| #######################################################################
\*=========================================================================*/
